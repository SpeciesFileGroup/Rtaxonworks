rtaxonworks 0.0.1
==========

### NEW FEATURES

* First submission to CRAN.
